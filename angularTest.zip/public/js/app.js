var app = angular.module('swingBook', ['ui.router']);

app.config([
'$stateProvider',
'$urlRouterProvider',
function($stateProvider, $urlRouterProvider) {
	$stateProvider
		.state('home', {
			url: '/home',
			templateUrl: '/home.html',
			controller: 'MainCtrl'
		})
		.state('events', {
			url: 'events/{id}',
			templateUrl: '/events.html',
			controller:'EventsCtrl'
		})
	$urlRouterProvider.otherwise('home')
}]);
	
app.factory('events', [function(){
	var o = {
		events: [
			{name: "Frim Fram", date: 'Thurs 9:00pm-1:00am', numAttendees: 0},
			{name: 'Brooklyn Swings', date: 'Fridays 7:30pm-10:00pm', numAttendees: 0},
			{name: 'Swing Practice', date: 'Tuesdays 9:00pm-11:00pm', numAttendees: 0}
		]
	};
	return o;
}]);

app.controller('MainCtrl', [
	'$scope',
	'events',
	function($scope, events){
		$scope.events = events.events;
		$scope.test = 'Hello world!';
		$scope.addEvent = function() {
			if(!$scope.name || $scope.name === '') return;
			if(!$scope.date || $scope.date === '') return;
			$scope.events.push({
				name: $scope.name, 
				date: $scope.date, 
				numAttendees: 0,
				messages: [
					{author: 'Joe', text: 'Can\'t wait for this.', date: '11/5 - 6:58:37PM'},
					{author: 'Bob', text: 'This is gonna be sick!', date: '11/5 - 6:59:15PM'}
				]
			});
		};
		$scope.addAttendee = function(event) {
			event.numAttendees++;
		}
}]);

app.controller('EventsCtrl', [
	'$scope',
	'$stateParams',
	'events',
	function($scope, $stateParams, events){
		$scope.event = events.events[$stateParams.id];
}]);